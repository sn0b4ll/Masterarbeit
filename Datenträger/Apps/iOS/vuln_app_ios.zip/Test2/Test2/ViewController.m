//
//  ViewController.m
//  Test2
//
//  Created by Dominik Schlecht on 26/06/16.
//  Copyright © 2016 Dominik Schlecht. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 50)];
    
    
    // Set the text property of the label
    label.text = @"Hello again!";
    
    // Add the label object to the view
    [self.view addSubview:label];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setTitle:@"Hello" forState:UIControlStateNormal];
    btn.frame = CGRectMake(25, 100, 275, 40);
    [btn addTarget:self action:@selector(someMethod:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    NSURL *url = [NSURL URLWithString:@"https://api.ipify.org"];
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSString *ret = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"ret=%@", ret);
    
    NSString *tileDirectory = [[NSBundle mainBundle] resourcePath];
    NSLog(@"path=%@", tileDirectory);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)someMethod:(UIButton *)sender {
    // handle button press
    
    char msg[15];
    char *str = "\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x42";
    strcpy(msg, str);
    //printf("%s", msg);
    
    NSError *requestError = nil;
    
    NSURL *url = [NSURL URLWithString:@"http://api.ipify.org"];
    NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingUncached error:&requestError];
    NSString *ret = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"ret=%@", ret);
    if (requestError) {
        NSLog(@"error=%@", [requestError localizedDescription]);
    }

    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"My Alert"
                                                                   message:ret
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];

    
    [MPMediaLibrary requestAuthorization:^(MPMediaLibraryAuthorizationStatus status){
        switch (status) {
            case MPMediaLibraryAuthorizationStatusNotDetermined: {
                NSLog(@"Media-Permission: Not determined");
                break;
            }
            case MPMediaLibraryAuthorizationStatusRestricted: {
                // restricted
                NSLog(@"Media-Permission: restricted");
                break;
            }
            case MPMediaLibraryAuthorizationStatusDenied: {
                // denied
                NSLog(@"Media-Permission: denied");
                break;
            }
            case MPMediaLibraryAuthorizationStatusAuthorized: {
                // authorized
                NSLog(@"Media-Permission: authorized");
                break;
            }
            default: {
                break;
            }
        }
    }];
}



@end
