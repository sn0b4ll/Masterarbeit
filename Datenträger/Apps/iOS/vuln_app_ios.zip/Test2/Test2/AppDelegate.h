//
//  AppDelegate.h
//  Test2
//
//  Created by Dominik Schlecht on 26/06/16.
//  Copyright © 2016 Dominik Schlecht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

